package com.cg.mobilebilling;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.boot.CgMobileBillingSystemSpringMvcJpaDataBootApplication;
import com.cg.mobilebilling.dao.BillDAO;
import com.cg.mobilebilling.dao.CustomerDAO;
import com.cg.mobilebilling.dao.PlanDAO;
import com.cg.mobilebilling.dao.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=CgMobileBillingSystemSpringMvcJpaDataBootApplication.class)
public class CgMobileBillingSystemSpringMvcJpaDataBootApplicationTests {
	@MockBean
	private PlanDAO planDao;
	@MockBean
	private BillDAO billDao;
	@MockBean
	private CustomerDAO customerDao;
	@MockBean
	private PostpaidAccountDAO postpaidAccountDao;
	@Autowired
	BillingServices services;
	
	@BeforeClass
	public static void setUpEnvironment() {
		System.out.println("Testing begins...");
	}
	@AfterClass
	public static void tearDownEnvironment() {
		System.out.println("...The End");
	}
	@Test
	public void checkValidInputAcceptCustomerDetailsTest() throws BillingServicesDownException {
		Customer customer = new Customer("Anakin", "Skywalker", "vader.darth@gmail.com", "11/11/2018", new Address(620021, "Tatooine", "Republic"));
		Customer customer1 = customer;
		customer1.setCustomerID(1001);
		Mockito.when(customerDao.save(customer)).thenReturn(customer1);
		assertThat(services.acceptCustomerDetails(customer)).isEqualTo(customer1);
	}
	@Test
	public void checkPlanDetails() throws BillingServicesDownException {
		List<Plan> plans = new ArrayList<>();
		Plan plan1 = new Plan(200, 50, 50, 50, 50, 100, 0.02f, 0.05f, 0.5f, 0.8f, 0.5f, "Gotham", "Caped Crusader");
		plans.add(plan1);
		Plan plan2 = new Plan(250, 50, 50, 50, 50, 120, 0.05f, 0.05f, 0.5f, 0.8f, 0.5f, "Metropolis", "Man of Steel");
		plans.add(plan2);
		Plan plan3 = new Plan(280, 50, 50, 50, 50, 150, 0.07f, 0.06f, 0.5f, 0.9f, 0.5f, "Themyscira", "Amazon Princess");
		plans.add(plan3);
		Mockito.when(planDao.findAll()).thenReturn(plans);
		assertThat(services.getPlanAllDetails()).isEqualTo(plans);
	}
}
