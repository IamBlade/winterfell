package com.cg.mobilebilling;
import java.util.ArrayList;
import java.util.List;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.boot.CgMobileBillingSystemSpringMvcJpaDataBootApplication;
import com.cg.mobilebilling.dao.BillDAO;
import com.cg.mobilebilling.dao.CustomerDAO;
import com.cg.mobilebilling.dao.PlanDAO;
import com.cg.mobilebilling.dao.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=CgMobileBillingSystemSpringMvcJpaDataBootApplication.class)
public class OpenPostpaidAccountTests {
	@MockBean
	private PlanDAO planDao;
	@MockBean
	private BillDAO billDao;
	@MockBean
	private CustomerDAO customerDao;
	@MockBean
	private PostpaidAccountDAO postpaidAccountDao;
	@Autowired
	BillingServices services;
	private  static Plan plan1,plan2,plan3;
	private  static List<Plan> plans;
	@BeforeClass
	public static void setUpEnvironment() {
		System.out.println("Testing begins...");
		Customer customer = new Customer("Anakin", "Skywalker", "vader.darth@gmail.com", "11/11/2018", new Address(620021, "Tatooine", "Republic"));
		plans = new ArrayList<>();
		plan1 = new Plan(200, 50, 50, 50, 50, 100, 0.02f, 0.05f, 0.5f, 0.8f, 0.5f, "Gotham", "Caped Crusader");
		plan1.setPlanID(101);
		plans.add(plan1);
		plan2 = new Plan(250, 50, 50, 50, 50, 120, 0.05f, 0.05f, 0.5f, 0.8f, 0.5f, "Metropolis", "Man of Steel");
		plan1.setPlanID(102);
		plans.add(plan2);
		plan3 = new Plan(280, 50, 50, 50, 50, 150, 0.07f, 0.06f, 0.5f, 0.9f, 0.5f, "Themyscira", "Amazon Princess");
		plan1.setPlanID(103);
		plans.add(plan3);
	}
	@AfterClass
	public static void tearDownEnvironment() {
		System.out.println("...The End");
	}
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void checkInvalidCustomerID() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		/*Mockito.when(planDao.findAll()).thenReturn(plans);
		Mockito.when(planDao.findById(101).orElseThrow(()->new PlanDetailsNotFoundException())).thenReturn(OpenPostpaidAccountTests.plan1);*/
		services.openPostpaidMobileAccount(1234, 101);
	}
}