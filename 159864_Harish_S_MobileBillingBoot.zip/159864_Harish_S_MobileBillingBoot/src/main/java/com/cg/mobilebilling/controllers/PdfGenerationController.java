package com.cg.mobilebilling.controllers;
import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.util.GeneratedPdfReport;

@RestController
public class PdfGenerationController {
	@Autowired
	BillingServices billingServiceProvider;
	@RequestMapping(value="/generateBillPdf", method=RequestMethod.POST, produces=MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity billDetailsPdf(@Param("PdfcustomerID") Integer customerID,@Param("PdfmobileNo") Long mobileNo,@Param("PdfbillMonth") String billMonth){
		try {
			@SuppressWarnings("unchecked")
			Bill bill = billingServiceProvider.getMobileBillDetails(customerID.intValue(), mobileNo.longValue(), billMonth);
			ByteArrayInputStream inputStream = GeneratedPdfReport.billsReport(bill);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "inline; filename=billReport.pdf");
			return ResponseEntity
					.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(inputStream));
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillDetailsNotFoundException | BillingServicesDownException e) {
			return ResponseEntity
		            .status(HttpStatus.EXPECTATION_FAILED)
		            .body(e.getMessage());
		}
	}
}
