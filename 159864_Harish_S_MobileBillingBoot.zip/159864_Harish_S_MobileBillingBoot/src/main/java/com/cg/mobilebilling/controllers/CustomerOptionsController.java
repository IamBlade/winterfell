package com.cg.mobilebilling.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerOptionsController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/acceptCustomerDetails")
	public String getCustomerEntryPage() {
		return "customerCreationPage";
	}
	@ModelAttribute("customer")
	public Customer getCustomer() {
		return new Customer();
	}
	@RequestMapping("/getCustomerDetails")
	public String getCustomerDetailsPage() {
		return "customerDetailsPage";
	}
	@RequestMapping("/getAllCustomerDetails")
	public ModelAndView getAllCustomerDetailsPage() {
		try {
			List<Customer> customers = billingServices.getAllCustomerDetails();
			return new ModelAndView("allCustomerDetailsPage", "customers", customers);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("allCustomerDetailsPage", "error", e.getMessage());
		}
	}
	@RequestMapping("/deleteCustomerDetails")
	public String getDeleteCustomerDetailsPage() {
		return "deleteCustomerPage";
	}	
}