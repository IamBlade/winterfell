package com.cg.mobilebilling.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostpaidAccount;

public interface BillDAO extends JpaRepository<Bill, Integer>{
	@Query("Select b from Bill b where b.postpaidAccount=:postpaidAccount and b.billMonth=:billMonth")
	Bill getMonthlyBill(@Param("postpaidAccount")PostpaidAccount postpaidAccount,@Param("billMonth") String billMonth);
	@Query("Select b from Bill b where b.postpaidAccount=:postpaidAccount")
	List<Bill> getPostpaidAccountBills(@Param("postpaidAccount")PostpaidAccount postpaidAccount);
	
}