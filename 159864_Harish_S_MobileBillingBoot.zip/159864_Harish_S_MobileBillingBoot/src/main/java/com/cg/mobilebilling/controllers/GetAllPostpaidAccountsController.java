package com.cg.mobilebilling.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class GetAllPostpaidAccountsController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/displayAllPostpaidAccounts")
	public ModelAndView getAllPostpaidAccountsPage(@Param("customerID")int customerID) {
		try {
			List<PostpaidAccount> postpaidAccounts= billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
			return new ModelAndView("allPostpaidAccountsPage", "postpaidAccounts", postpaidAccounts);
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("allPostpaidAccountsPage", "error", e.getMessage());
		}
	}
}
