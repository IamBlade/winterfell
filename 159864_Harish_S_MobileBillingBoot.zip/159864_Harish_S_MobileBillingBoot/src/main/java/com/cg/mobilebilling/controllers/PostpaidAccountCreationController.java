package com.cg.mobilebilling.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class PostpaidAccountCreationController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/createPostpaidAccount")
	public ModelAndView openPostpaidAccount(@Param("customerID") int customerID, @Param("planID")int planID) {
		try {
			return new ModelAndView("openPostpaidAccountSuccessPage", "postpaidAccount", billingServices.openPostpaidMobileAccount(customerID, planID));
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("openPostpaidAccountPage", "error", e.getMessage());
		}
	}
}
