package com.cg.mobilebilling.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class BillGenerationController {
	@Autowired
	BillingServices services;
	@RequestMapping("/generateBill")
	public ModelAndView getTotalBill( @Valid @ModelAttribute Bill bill, BindingResult result) {
		if(result.hasErrors())
			return new ModelAndView("billingPage");
		int billAmount;
		try {
			billAmount = services.generateMonthlyMobileBill(bill.getPostpaidAccount().getCustomer().getCustomerID(), bill.getPostpaidAccount().getMobileNo(), bill);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillingServicesDownException | PlanDetailsNotFoundException e) {
			return new ModelAndView("billingPage", "error", e.getMessage());
		}
		return new ModelAndView("billingPage", "totalBill", billAmount);
	}
}
