package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class PostpaidAccountDestroyController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/destroyPostpaidAccount")
	public ModelAndView openPostpaidAccount(@Param("customerID") int customerID,@Param("mobileNo") long mobileNo) {
		try {
			billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
			return new ModelAndView("closePostpaidAccountPage", "status", "Account deleted");
		} catch ( CustomerDetailsNotFoundException | BillingServicesDownException | PostpaidAccountNotFoundException | BillDetailsNotFoundException e) {
			return new ModelAndView("closePostpaidAccountPage", "error", e.getMessage());
		}
	}
}
