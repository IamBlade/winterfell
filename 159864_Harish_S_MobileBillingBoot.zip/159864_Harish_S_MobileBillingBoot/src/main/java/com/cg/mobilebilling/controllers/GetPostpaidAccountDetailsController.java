package com.cg.mobilebilling.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class GetPostpaidAccountDetailsController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/displayPostpaidAccountDetails")
	public ModelAndView getCustomerDetails(@Param("customerID") int customerID, @Param("mobileNo") long mobileNo) {
		try {
			PostpaidAccount postpaidAccount = billingServices.getPostPaidAccountDetails(customerID, mobileNo);
			return new ModelAndView("postpaidAccountDetailsPage", "postpaidAccount", postpaidAccount);
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException | PostpaidAccountNotFoundException e) {
			return new ModelAndView("postpaidAccountDetailsPage", "error", e.getMessage());
		}
	}
}