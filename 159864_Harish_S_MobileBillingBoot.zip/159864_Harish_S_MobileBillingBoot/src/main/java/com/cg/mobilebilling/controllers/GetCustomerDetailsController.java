package com.cg.mobilebilling.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class GetCustomerDetailsController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/displayCustomerDetails")
	public ModelAndView getCustomerDetails(@Param("customerID") int customerID) {
		try {
			Customer customer = billingServices.getCustomerDetails(customerID);
			return new ModelAndView("customerDetailsPage", "customer", customer);
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("customerDetailsPage", "error", e.getMessage());
		}
	}
}
