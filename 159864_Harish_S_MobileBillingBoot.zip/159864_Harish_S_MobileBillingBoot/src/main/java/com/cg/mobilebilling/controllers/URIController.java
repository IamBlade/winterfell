package com.cg.mobilebilling.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class URIController {
	@Autowired
	BillingServices services;
	
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/home")
	public String getHomePage() {
		return "indexPage";
	}
	@RequestMapping("/displayCustomerOps")
	public String getCustomerOps() {
		return "customerOpsPage";
	}
	@RequestMapping("/displayPostpaidAccountOps")
	public String getPostpaidAccountOps() {
		return "postpaidAccountOpsPage";
	}
	@RequestMapping("/displayBillOps")
	public String getBillOps() {
		return "billOpsPage";
	}
	@RequestMapping("/displayPlanOps")
	public ModelAndView getPlanOps() {
		try {
			return new ModelAndView("planOpsPage", "plans", services.getPlanAllDetails());
		} catch (BillingServicesDownException e) {
			return new ModelAndView("planOpsPage", "error", "Error occured. Swoowy");
		}
	}
	
}
