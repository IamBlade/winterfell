package com.cg.mobilebilling.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class GetAllBillsController {
	@Autowired
	BillingServices services;
	@RequestMapping("/displayAllBills")
	public ModelAndView getAllBills(@Param("customerID") int customerID,@Param("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException {
		return new ModelAndView("billAllDetailsPage", "bills", services.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo));
	}
}