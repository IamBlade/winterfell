package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class CustomerDeletionController {
	@Autowired
	BillingServices services;
	@RequestMapping("/deleteCustomer")
	public ModelAndView deleteCustomerDetails(@Param("customerID")int customerID) {
				try {
					if(services.deleteCustomer(customerID))
						return new ModelAndView("deleteCustomerPage", "success", "Customer details of ID: "+customerID+"successfully deleted");
					else
						return new ModelAndView("deleteCustomerPage", "error", "Some error occured. Try later");
				} catch (BillingServicesDownException | CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillDetailsNotFoundException e) {
					return new ModelAndView("deleteCustomerPage", "error", e.getMessage());
				}
	}
}
