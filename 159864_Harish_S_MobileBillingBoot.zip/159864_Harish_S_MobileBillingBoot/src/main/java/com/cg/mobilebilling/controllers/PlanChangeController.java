package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class PlanChangeController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/changePostpaidPlan")
	public ModelAndView openPostpaidAccount(@Param("customerID") int customerID,@Param("mobileNo") long mobileNo, @Param("planID")int planID) {
		try {
			billingServices.changePlan(customerID, mobileNo, planID);
			return new ModelAndView("changePlanPage", "status", "Plan changed succesfully to "+ planID);
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException | PostpaidAccountNotFoundException e) {
			return new ModelAndView("changePlanPage", "error", e.getMessage());
		}
	}
}

