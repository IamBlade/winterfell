package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class BillOptionsController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/displayMonthlyBill")
	public String getBillingPage() {
		return "billingPage";
	}
	@ModelAttribute("bill")
	public Bill getBill() {
		return new Bill();
	}
	@RequestMapping("/getBillDetails")
	public String getBillDetails() {
		return "billDetailsPage";
	}
	@RequestMapping("/getAllBills")
	public String getAllBillDetails() {
		return "billAllDetailsPage";
	}
}
