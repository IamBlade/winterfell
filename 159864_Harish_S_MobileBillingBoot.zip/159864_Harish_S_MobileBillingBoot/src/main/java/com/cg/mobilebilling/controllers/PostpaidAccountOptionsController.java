package com.cg.mobilebilling.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class PostpaidAccountOptionsController {
	@RequestMapping("/openPostpaidAccount")
	public String getOpenPostpaidAccount() {
		return "openPostpaidAccountPage";
	}
	@RequestMapping("/getPostpaidAccountDetails")
	public String getPostpaidAccountDetails() {
		return "postpaidAccountDetailsPage";
	}
	@RequestMapping("/getCustomerAllPostpaidAccountDetails")
	public String getCustomerAllPostpaidAccount() {
		return "allPostpaidAccountsPage";
	}
	@RequestMapping("/changePlan")
	public String getChangePlan() {
		return "changePlanPage";
	}
	@RequestMapping("/closePostpaidAccount")
	public String getClosePostpaidAccount() {
		return "closePostpaidAccountPage";
	}
}
