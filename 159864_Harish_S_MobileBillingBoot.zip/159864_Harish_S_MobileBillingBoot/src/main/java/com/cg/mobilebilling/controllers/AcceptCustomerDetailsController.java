package com.cg.mobilebilling.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class AcceptCustomerDetailsController {
	@Autowired
	BillingServices services;
	@RequestMapping("/createCustomer")
	public ModelAndView acceptCustomerDetails(@Valid @ModelAttribute Customer customer, BindingResult result) {
		if(result.hasErrors())
			return new ModelAndView("customerCreationPage");
		try {
			customer = services.acceptCustomerDetails(customer);
			return new ModelAndView("customerCreationSuccessPage", "customer", customer);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("customerCreationPage", "error", e.getMessage());
		}
	}
}