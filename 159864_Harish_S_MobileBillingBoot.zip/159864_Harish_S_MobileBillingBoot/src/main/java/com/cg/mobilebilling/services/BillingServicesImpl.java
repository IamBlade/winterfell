package com.cg.mobilebilling.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.dao.BillDAO;
import com.cg.mobilebilling.dao.CustomerDAO;
import com.cg.mobilebilling.dao.PlanDAO;
import com.cg.mobilebilling.dao.PostpaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
@Transactional
public class BillingServicesImpl implements BillingServices {

	private int calculateBill(Bill bill) throws PlanDetailsNotFoundException {
		Plan plan = bill.getPlan();
		if(plan!=null) {
			bill.setTotalBillAmount(plan.getMonthlyRental());
			bill.setLocalCallAmount(plan.getFreeLocalCalls()>=bill.getNoOfLocalCalls()?0:(bill.getNoOfLocalCalls()*plan.getLocalCallRate()));
			bill.setLocalSMSAmount(plan.getFreeLocalSMS()>=bill.getNoOfLocalSMS()?0:(bill.getNoOfLocalSMS()*plan.getLocalSMSRate()));
			bill.setStdCallAmount(plan.getFreeStdCalls()>bill.getNoOfStdCalls()?0:(bill.getNoOfStdCalls()*plan.getStdCallRate()));
			bill.setStdSMSAmount(plan.getFreeStdSMS()>bill.getNoOfStdSMS()?0:(bill.getNoOfStdSMS()*plan.getStdSMSRate()));
			bill.setInternetDataUsageAmount(plan.getFreeInternetDataUsageUnits()>=bill.getInternetDataUsageUnits()?0:(bill.getInternetDataUsageUnits()*plan.getInternetDataUsageRate()));
			bill.setTotalBillAmount(bill.getLocalCallAmount()+bill.getLocalSMSAmount()+bill.getStdCallAmount()+bill.getStdSMSAmount()+bill.getInternetDataUsageAmount());
			bill.setVat(bill.getTotalBillAmount()*0.2f);
			bill.setServicesTax(bill.getTotalBillAmount()*0.15f);
			bill.setTotalBillAmount(bill.getTotalBillAmount()+bill.getVat()+bill.getServicesTax());
			return (int)bill.getTotalBillAmount();
		}
		else
			throw new PlanDetailsNotFoundException();
	}

	@Autowired
	CustomerDAO customerDao;
	@Autowired
	BillDAO billDAO;
	@Autowired
	PlanDAO planDAO;
	@Autowired
	PostpaidAccountDAO postpaidAccountDAO;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		if(planDAO.findAll().isEmpty()) {
			Plan plan1 = new Plan(200, 50, 50, 50, 50, 100, 0.02f, 0.05f, 0.5f, 0.8f, 0.5f, "Gotham", "Caped Crusader");
			planDAO.save(plan1);
			Plan plan2 = new Plan(250, 50, 50, 50, 50, 120, 0.05f, 0.05f, 0.5f, 0.8f, 0.5f, "Metropolis", "Man of Steel");
			planDAO.save(plan2);
			Plan plan3 = new Plan(280, 50, 50, 50, 50, 150, 0.07f, 0.06f, 0.5f, 0.9f, 0.5f, "Themyscira", "Amazon Princess");
			planDAO.save(plan3);
		}
		return planDAO.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		return customerDao.save(customer);
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		if(planDAO.findAll().isEmpty())
			getPlanAllDetails();
		Plan plan = planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("No plan found"));
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		PostpaidAccount postpaidAccount = new PostpaidAccount(plan, customer);
		postpaidAccountDAO.save(postpaidAccount);
		customer.getPostpaidAccounts().put(postpaidAccount.getMobileNo(), postpaidAccount);
		customerDao.save(customer);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, Bill bill)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		Map<Long,PostpaidAccount> postpaidAccounts = customer.getPostpaidAccounts();
		if(postpaidAccounts==null || postpaidAccounts.isEmpty())
			throw new PostpaidAccountNotFoundException();
		else if(!postpaidAccounts.containsKey(mobileNo))
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else {
			bill.setPlan(postpaidAccounts.get(mobileNo).getPlan());
			bill.setPostpaidAccount(postpaidAccounts.get(mobileNo));
			calculateBill(bill);
			billDAO.save(bill);
			return (int) bill.getTotalBillAmount();
		}

	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> customers = customerDao.findAll();
		if(customers==null || customers.isEmpty())
			throw new BillingServicesDownException("No customers");
		else
			return customers;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else
			return customer.getPostpaidAccounts().get(mobileNo);
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		return new ArrayList<>(customer.getPostpaidAccounts().values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else {
			Bill bill = billDAO.getMonthlyBill(customer.getPostpaidAccounts().get(mobileNo), billMonth);
			if(bill==null)
				throw new BillDetailsNotFoundException("No bill for this month");
			else
				return bill;
		}
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else 
			return billDAO.getPostpaidAccountBills(customer.getPostpaidAccounts().get(mobileNo));
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		Plan plan = planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("No plans with this ID"));
		postpaidAccountDAO.findById(mobileNo).get().setPlan(plan);
		return true;

	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		 if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else {
			postpaidAccountDAO.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("No account found"));
			List<Bill> bills = getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
			for(Bill bill : bills) 
				billDAO.deleteById(bill.getBillID());
			postpaidAccountDAO.deleteById(mobileNo);
			return true;
		}
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillDetailsNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		ArrayList<PostpaidAccount> postpaidAccounts = (ArrayList<PostpaidAccount>) getCustomerAllPostpaidAccountsDetails(customerID);
		for(PostpaidAccount postpaidAccount:postpaidAccounts)
			closeCustomerPostPaidAccount(customerID, postpaidAccount.getMobileNo());
		customerDao.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		if(customer.getPostpaidAccounts().get(mobileNo)==null)
			throw new PostpaidAccountNotFoundException("Account not found under given customer ID");
		else if(customer.getPostpaidAccounts().get(mobileNo).getPlan()==null)
			throw new PlanDetailsNotFoundException("No plan assigned to this account");
		else
			return customer.getPostpaidAccounts().get(mobileNo).getPlan();
	}

	@Override
	public int acceptPlanDetails(Plan plan) {
		return planDAO.save(plan).getPlanID();
	}
}